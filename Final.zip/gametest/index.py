from othello import Othello, MOVE_DIRS


def main():
    game = Othello()
    # game.choose_difficulty()
    game.draw_board()
    game.initialize_board()

    game.run()

main()