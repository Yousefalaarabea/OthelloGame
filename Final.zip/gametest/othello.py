import score
import turtle
import random
from board import Board

MOVE_DIRS = [(-1, -1), (-1, 0), (-1, +1),
             (0, -1),           (0, +1),
             (+1, -1), (+1, 0), (+1, +1)]


class Othello(Board):
    def __init__(self, n=8):
        turtle.title('Othello')
        Board.__init__(self, n)
        self.current_player = 0
        self.num_tiles = [2, 2]
        self.past_legal_moves = []
        self.depth = 4

    def initialize_board(self):
        if self.n < 2:
            return

        coord1 = int(self.n / 2 - 1)
        coord2 = int(self.n / 2)
        initial_squares = [(coord1, coord2), (coord1, coord1),
                           (coord2, coord1), (coord2, coord2)]

        for i in range(len(initial_squares)):
            color = i % 2
            row = initial_squares[i][0]
            col = initial_squares[i][1]
            self.board[row][col] = color + 1
            self.draw_tile(initial_squares[i], color)
            self.display_possible_moves()

    def display_score(self):
        turtle.clear()
        score_str = f"Black: {self.num_tiles[0]} '     ' White: {self.num_tiles[1]}"
        turtle.penup()
        turtle.goto(-200, 200)  # Adjust coordinates as per your preference
        turtle.write(score_str, font=("Arial", 16, "normal"))

    def make_move(self):
        if self.is_legal_move(self.move):
            self.board[self.move[0]][self.move[1]] = self.current_player + 1
            self.num_tiles[self.current_player] += 1
            self.draw_tile(self.move, self.current_player)
            self.flip_tiles()
            self.display_score()

    def flip_tiles(self):
        curr_tile = self.current_player + 1
        for direction in MOVE_DIRS:
            if self.has_tile_to_flip(self.move, direction):
                i = 1
                while True:
                    row = self.move[0] + direction[0] * i
                    col = self.move[1] + direction[1] * i
                    if self.board[row][col] == curr_tile:
                        break
                    else:
                        self.board[row][col] = curr_tile
                        self.num_tiles[self.current_player] += 1
                        self.num_tiles[(self.current_player + 1) % 2] -= 1
                        self.draw_tile((row, col), self.current_player)
                        i += 1

    def has_tile_to_flip(self, move, direction):
        i = 1
        if self.current_player in (0, 1) and self.is_valid_coord(move[0], move[1]):
            curr_tile = self.current_player + 1
            while True:
                row = move[0] + direction[0] * i
                col = move[1] + direction[1] * i
                if not self.is_valid_coord(row, col) or self.board[row][col] == 0:
                    return False
                elif self.board[row][col] == curr_tile:
                    break
                else:
                    i += 1

        return i > 1

    def has_legal_move(self):
        for row in range(self.n):
            for col in range(self.n):
                move = (row, col)
                if self.is_legal_move(move):
                    return True
        return False

    def get_legal_moves(self):
        moves = []
        for row in range(self.n):
            for col in range(self.n):
                move = (row, col)
                if self.is_legal_move(move):
                    moves.append(move)
        return moves

    def is_legal_move(self, move):
        if move != () and self.is_valid_coord(move[0], move[1]) and self.board[move[0]][move[1]] == 0:
            for direction in MOVE_DIRS:
                if self.has_tile_to_flip(move, direction):
                    return True
        return False

    def is_valid_coord(self, row, col):
        if 0 <= row < self.n and 0 <= col < self.n:
            return True
        return False

    def choose_difficulty(self):
        print("Select difficulty level:")
        print("1. Easy")
        print("2. Medium")
        print("3. Hard")

        while True:
            try:
                choice = int(input("Enter the number corresponding to your choice: "))
                if choice in (1, 2, 3):
                    if choice == 1:
                        self.depth = 2
                    elif choice == 2:
                        self.depth = 4
                    elif choice == 3:
                        self.depth = 6
                    break
                else:
                    print("Invalid choice. Please enter a number between 1 and 3.")
            except ValueError:
                print("Invalid input. Please enter a number.")

    def run(self):
        self.choose_difficulty()
        if self.current_player not in (0, 1):
            print('Error, unknown player. Quitting...')
            return

        self.current_player = 0
        print('Your Turn..')
        turtle.onscreenclick(self.play)
        turtle.mainloop()

    def display_possible_moves(self):
        self.past_legal_moves = self.get_legal_moves()
        for move in self.get_legal_moves():
            self.draw_dot(move, 0)

    def clean_possible_moves(self):
        for move in self.past_legal_moves:
            if move != self.move:
                self.draw_dot(move, 1)
        self.past_legal_moves.clear()

    def play(self, x, y):

        if self.has_legal_move():
            self.display_possible_moves()
            self.get_coord(x, y)
            if self.is_legal_move(self.move):
                turtle.onscreenclick(None)
                self.make_move()
            else:
                return

        self.clean_possible_moves()

        while True:
            self.clean_possible_moves()
            self.current_player = 1
            if self.has_legal_move():
                print('Computer\'s turn..')
                self.make_computer_move(depth=3)  # Adjust the depth here
                self.current_player = 0
                if self.has_legal_move():
                    break
            else:
                break

        self.clean_possible_moves()
        self.display_possible_moves()
        self.current_player = 0

        if not self.has_legal_move() or sum(self.num_tiles) == self.n ** 2:
            turtle.onscreenclick(None)
            print('--------------')
            self.report_result()
            print('Thank you for playing!')
        else:
            print('Your Turn..')
            turtle.onscreenclick(self.play)

    def make_computer_move(self, depth):
        move, _ = self.computer_hard(depth, float('-inf'), float('inf'), -1)
        if move:
            self.move = move
            self.make_move()
        else:
            print("Computer passes.")

    def computer_hard(self, depth, alpha, beta, User):
        new_board = [row[:] for row in self.board]
        legal_moves = self.get_legal_moves()

        if depth == 0 or len(legal_moves) == 0:
            score = self.evaluate_board()
            return None, score

        if User == 1:
            best_score = float('-inf')
            best_move = None

            for move in legal_moves:
                x, y = move
                swappable_tiles = self.get_swappable_tiles(x, y, User)
                new_board[x][y] = User

                for tile in swappable_tiles:
                    new_board[tile[0]][tile[1]] = User

                _, value = self.computer_hard(depth - 1, alpha, beta, -User)

                if value > best_score:
                    best_score = value
                    best_move = move

                alpha = max(alpha, best_score)
                if beta <= alpha:
                    break

                new_board = [row[:] for row in self.board]

            return best_move, best_score

        elif User == -1:
            best_score = float('inf')
            best_move = None

            for move in legal_moves:
                x, y = move
                swappable_tiles = self.get_swappable_tiles(x, y, User)
                new_board[x][y] = User

                for tile in swappable_tiles:
                    new_board[tile[0]][tile[1]] = User

                _, value = self.computer_hard(depth - 1, alpha, beta, -User)

                if value < best_score:
                    best_score = value
                    best_move = move

                beta = min(beta, best_score)
                if beta <= alpha:
                    break

                new_board = [row[:] for row in self.board]

            return best_move, best_score

    def evaluate_board(self):
        # You can implement your own board evaluation function here
        # For simplicity, let's return a random score for now
        return random.randint(-100, 100)

    def report_result(self):
        print('Game over:)')
        if self.num_tiles[0] > self.num_tiles[1]:
            print('You are the Winner :)',
                  'You have %d tiles , but the computer has %d tiles'
                  % (self.num_tiles[0], self.num_tiles[1]))
        elif self.num_tiles[0] < self.num_tiles[1]:
            print('You Lose :(',
                  'the computer has %d tiles, but you have %d tiles'
                  % (self.num_tiles[1], self.num_tiles[0]))
        else:
            print('Draw!! Both of You Got %d tiles' % (self.num_tiles[0]))

    def __str__(self):
        player_str = 'Current Player: ' + str(self.current_player + 1) + '\n'
        num_tiles_str = ('# of black tiles -- 1: ' + str(self.num_tiles[0]) + \
                         '\n' + '# of white tiles -- 2' + str(self.num_tiles[1]) + '\n')
        board_str = Board.__str__(self)
        printable_str = player_str + num_tiles_str + board_str
        return printable_str

    def __eq__(self, other):
        return Board.__eq__(self, other) and self.current_player == other.current_player

    def get_swappable_tiles(self, x, y, player):
        swappable_tiles = []
        for direction in MOVE_DIRS:
            dx, dy = direction
            nx, ny = x + dx, y + dy
            temp = []
            while self.is_valid_coord(nx, ny) and self.board[nx][ny] == -player:
                temp.append((nx, ny))
                nx, ny = nx + dx, ny + dy
                if self.is_valid_coord(nx, ny) and self.board[nx][ny] == player:
                    swappable_tiles.extend(temp)
        return swappable_tiles


